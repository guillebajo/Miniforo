
<form name='Nueva opinión' method="GET">
<table>
<tr>
<td>Tema:</td> <td> <input type="text" name="tema" value=<?php echo $_REQUEST['tema'];?>> </td></tr>
<tr>
<td>Comentario: </td> <td><input type="text" name="comentario" maxlength="300" value=<?php echo $_REQUEST['comentario'];?>></td>
</tr>

</table>
<input type="submit" name="orden" value="Nueva opinión">
<input type="submit" name="orden" value="Detalles">
<input type="submit" name="orden" value="Terminar">
</form>