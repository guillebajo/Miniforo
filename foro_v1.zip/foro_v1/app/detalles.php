<?php
echo "Detalles:";
echo "<br>";
echo "Longitud:";
    $longitud = strlen($_REQUEST['comentario']);
echo $longitud;