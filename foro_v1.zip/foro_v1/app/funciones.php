<?php

function usuarioOK($nombre,$contraseña){
    $result = false;
    $falsa = strrev($nombre);
    
    if(strlen($nombre) >= 8){
        if($contraseña == $falsa){
            $result = true;
        }
    }
    return $result;
}
?>